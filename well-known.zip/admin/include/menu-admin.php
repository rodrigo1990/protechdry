<div class="row" id="menu-fixed" >

		<div class="menu hidden-xs hidden-sm col-md-12 col-lg-12">
			<div class="container">

				<img src="../elementos_separados/logo.png" class="element-menu img-responsive" onClick="window.location='usuario-admin.php'" id="logo-menu" width="210">
					
				<h4 class="seguro-menu" style="margin-left:3%;"><a href="index.php">Cerrar Sesion</a></h4>
				<h4 class="seguro-menu gris ">ADMINISTRADOR </h4>


			</div><!-- container -->

		</div><!-- menu -->
			<div class="menu col-xs-12 hidden-sm hidden-md hidden-lg">
			<div class="container">

				<img src="../elementos_separados/logo.png" class="element-menu img-responsive" onClick="window.location='index.php'" id="logo-menu" width="130">
					
				<h4 class="seguro-menu ">Cerrar Sesion </h4>

				<h4 class="seguro-menu gris">ADMINISTRADOR</h4>

			</div><!-- container -->

		</div><!-- menu -->
			<div class="menu hidden-xs col-sm-12 hidden-md hidden-lg">
			<div class="container">

				<img src="../elementos_separados/logo.png" class="element-menu img-responsive" onClick="window.location='index.php'" id="logo-menu" width="180">
					
				<h4 class="seguro-menu ">Cerrar Sesion </h4>>

				<h4 class="seguro-menu gris">ADMINISTRADOR</h4>


			</div><!-- container -->

		</div><!-- menu -->
	</div><!-- row  -->
	<!-- FIN MENU -->