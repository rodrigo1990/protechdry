<!-- FOOTER -->
<footer >
<div class="gradient-border" style="margin-top:5%;"></div>
<div class="row row-footer-fila-1">
	<div class="footer-fila-1 col-xs col-sm-12 col-md-12 col-lg-12">
		<div class="container">
		

		</div>
	</div>
</div>

<div class="row row-footer-fila-2" style="padding: 3%;">
	<div class="container">

		<div class="footer-fila-2 col-xs-12 col-sm-12 col-md-3 col-lg-3">

			<img id="footer-logo" src="elementos_separados/logo.png" alt="" width="50%" class="img-responsive">

		</div><!--  col 4 -->

		<div class="footer-fila-2-col-2 col-xs-12 col-sm-12 col-md-3 col-lg-3">
			<ul>
				<li><a href="comoComprar.php">COMÓ COMPRAR</a></li>
				<li><a href="comoComprar.php">ENVÍOS</a></li>
				<li><a href="comoComprar.php">POLITICA DE CAMBIOS</a></li>
				<li><a data-toggle='modal' data-target='#lista-de-talles-modal'>GUIA DE TALLES</a></li>
				<li><a href="https://www.mercadopago.com.ar/activities" target="_blank">METODOS DE PAGO</a></li>
			</ul>	
		</div><!--  col 4 -->

		<div class="footer-fila-2-col-2 col-xs-12 col-sm-12 col-md-3 col-lg-3">
			
			<ul>
				<li><a href="sobreNosotros.php">SOBRE PROTECH DRY</a></li>
				<li><a href="todosLosProductosHombres.php">HOMBRES</a></li>
				<li><a href="todosLosProductosMujeres.php">MUJERES</a></li>
				<li><img src="elementos_separados/mercadopago-icon.png" alt="" ></li>
			</ul>
		</div><!--  col 4 -->

		<div class="footer-fila-2-col-2 col-xs-12 col-sm-12 col-md-3 col-lg-3">
			<ul class="contact">
				<li><img src="img/icons/footer-icon-10.png" alt=""><p>011 4-919-1500/1800</p></li>
				<li><a href="mailTo: info@protechdry.com.ar"><img src="img/icons/footer-icon-11.png"  alt=""><p> info@protechdry.com.ar	</p></a></li>
				<li><a href="https://www.instagram.com/protechdryargentina/"target="_blank"><img src="img/icons/footer-icon-12.png" alt=""><p>/protechdryargentina</p></a></li>
				<li><a href="https://www.facebook.com/ProtechDryArgentina/" target="_blank"><img src="img/icons/footer-icon-13.png" alt=""><p>/protechdryargentina</p></a></li>
			</ul>
		</div><!--  col 4 -->
	</div>
</div>
</footer>