<div class="row" id="menu-fixed" >

		<div class="menu row">
			<div class="container">
				<div class="hidden-sm hidden-xs col-lg-6 col-md-6">
					<a href="index.php">
						<img src="elementos_separados/logo.png" class="element-menu img-responsive" onClick="window.location='index.php'" id="logo-menu" width="210">
					</a>
				</div>
				<div class="hidden-sm hidden-xs col-lg-6 col-md-6">
					
					<div class="seguro" style="float:right;padding-bottom:15px;">
						<h4 class="seguro-menu" style="margin:0;">Compra seguro</h4><br>
						<img class='' src="elementos_separados/mercadopago-icon.png"   alt="">
					</div>

			</div>
			</div><!-- container -->

		</div><!-- menu -->
			<div class="menu col-xs-12 hidden-sm hidden-md hidden-lg">
			<div class="container">
				<a href="index.php">
					<img src="elementos_separados/logo.png" class="element-menu img-responsive" onClick="window.location='index.php'" id="logo-menu" width="130">
				</a>
				<div>
					<h5 class="seguro-menu">¡Compra 100% segura!</h5>
				</div>
			</div><!-- container -->

		</div><!-- menu -->
			<div class="menu hidden-xs col-sm-12 hidden-md hidden-lg">
			<div class="container">
				<a href="index.php">
					<img src="elementos_separados/logo.png" class="element-menu img-responsive" onClick="window.location='index.php'" id="logo-menu" width="180">
				</a>
				<h4 class="seguro-menu">¡Compra 100% segura!</h4>
				<i class="candado-sm candado-icon-menu material-icons">https</i>


			</div><!-- container -->

		</div><!-- menu -->
	</div><!-- row  -->
	<!-- FIN MENU -->
	<div class="row"  id="primer-row-xs" >

		<div class="menu row">
			<div class="container">
				<div class="hidden-sm hidden-xs col-lg-6 col-md-6">
					<a href="index.php">
						<img src="elementos_separados/logo.png" class="element-menu img-responsive" onClick="window.location='index.php'" id="logo-menu" width="210">
					</a>
				</div>
				<div class="hidden-sm hidden-xs col-lg-6 col-md-6">
					
					<div class="seguro" style="float:right;padding-bottom:15px;">
						<h4 class="seguro-menu" style="margin:0;">Compra seguro</h4><br>
						<img class='' src="elementos_separados/mercadopago-icon.png"   alt="">
					</div>

			</div>
			</div><!-- container -->

		</div><!-- menu -->
			<div class="menu col-xs-12 hidden-sm hidden-md hidden-lg">
			<div class="container">
				<a href="index.php">
					<img src="elementos_separados/logo.png" class="element-menu img-responsive" onClick="window.location='index.php'" id="logo-menu" width="130">
				</a>
				<div>
					<h5 class="seguro-menu">¡Compra 100% segura!</h5>
				</div>
			</div><!-- container -->

		</div><!-- menu -->
			<div class="menu hidden-xs col-sm-12 hidden-md hidden-lg">
			<div class="container">
				<a href="index.php">
					<img src="elementos_separados/logo.png" class="element-menu img-responsive" onClick="window.location='index.php'" id="logo-menu" width="180">
				</a>
				<h4 class="seguro-menu">¡Compra 100% segura!</h4>
				<i class="candado-sm candado-icon-menu material-icons">https</i>


			</div><!-- container -->

		</div><!-- menu -->
	</div><!-- row  -->
	<!-- FIN MENU XS -->