<!-- Set up your HTML -->
	<div id="slider-sm-lg" class="owl-carousel owl-theme" style="">
	  <div>
	  	<img src="banners/banner_1.jpg"  width="100%" alt="Protech Dry">
		<div class="banner-info" id="banner-1">
			<div class="text-left center-block" style="    width: 100%;
    text-align: left;
    padding-left: 41%;
">
				<img src="img/icons/banner_1_icon.png" width="200px" alt="" style="display:inline-block;    margin-top: -8px;">
				<h3 style="display:inline-block;"><b>+100 LAVADOS</b></h3>
				<h1>Un <b>gran cambio</b> <br> para tu vida</h1>
				<h3><b>Conocé nuestros productos</b></h3>
				<div class="btn-cont" style="margin-top: 26px !important;">
		  		<a class="banner-btn"href="todosLosProductos.php">COMPRAR</a>
		  	</div>
			</div>
		</div>

	  </div>
	  <!--<div>
	  	<img src="banners/banner_2.jpg"  width="100%" alt="Protech Dry">
	  	<div class="banner-info" id='banner-2'>
	  		<div class="line center-block" style="width:564px;">
		  		<img src="img/icons/ue.png" class="img-responsive" style="    width: 50px!important;display: inline-block;vertical-align: middle;margin-top: -12px;" alt="">
			  	<H3 class="" id='tit-ue' style="display:inline-block;    margin-bottom: 4px;">
			  		PRODUCTO DE LA U.E -  Ahora en Argentina
			  	</H3>
		  	</div>
		  	<!--<h3 class="line">Ropa interior de algodón</h3>-->
		  	<!--<h1  class="line"id='tit-celeste'>RECOMENDADA PARA <br> INCONTINENCIA LEVE Y MODERADA</h1>-->
		  <!--	<div class="line">
		  		<hr><h3 id='tit-hr'>Lanzamiento</h3><hr>
		  	</div>
		  	<h1  class="line big">20%OFF</h1>
		  	<h4 class="line">Validez hasta el 30 de junio</h4>
		  	<div class="btn-cont">
		  		<a class="banner-btn"href="todosLosProductos.php">COMPRAR</a>
		  	</div>
	  	</div>
	  </div>-->
	  <div>
	      <img src="banners/banner_3.jpg"  width="100%" alt="Protech Dry">
	      <div class="banner-info" id='banner-3'>
	  		<div class="line center-block" style="width:564px;">
		  		<img src="img/icons/camion.png" class="img-responsive" style="    width:133px!important;display: inline-block;vertical-align: middle;margin-top: -12px;" alt="">
			  	<h1 class="big-3" style=""  >
			  		ENV&#205;O GRATUITO  
			  	</h1>
			  	<h1 class="big-3" style="">
			  	   CABA Y GRAN BUENOS AIRES 
			  	</h1>
			  	<h1 class="small-3" style="">ENV&#205;OS A TODO EL PA&#205;S</h1>
		  	</div>
		  	<div class="btn-cont">
		  		<a class="banner-btn-white"href="todosLosProductos.php">COMPRAR</a>
		  	</div>
	  	</div>
	      
	      
	      </div>

	</div>
	
	
	<!-- Set up your HTML -->
	<div id="slider-xs-sm" class="owl-carousel " style="">
	  <div><img src="banners/banner_xs_1.jpg"  width="100%" alt="Protech Dry"></div>
	  <div><img src="banners/banner_xs_2.jpg"  width="100%" alt="Protech Dry"></div>
	  <div><img src="banners/banner_xs_3.jpg"  width="100%" alt="Protech Dry"></div>

	</div>