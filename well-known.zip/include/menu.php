<!--<div class="row" id="primer-row" STYLE="    PADDING: 4PX;BACKGROUND-COLOR:WHITESMOKE;">
    <div class="text-center">
        <P STYLE="    FONT-FAMILY: Montserrat-regular;
    FONT-SIZE: 1.2REM;
    MARGIN: 0;
    COLOR: #100505;
    LETTER-SPACING: 3PX;">CONTACTO DIRECTO:<B>011 15 5473 2203</B> TELEFONO: <B>011 4-919-1500/1800</B></P>
    </div>
</div>-->
<div class="row menu" id="primer-row" style="padding: 2% 1% 1%;z-index: 10000;">
	<div class="container">
		<div class="col-lg-3 col-md-3 col-sm-2 col-xs-6">
			<a href="index.php">
				<img src="elementos_separados/logo.png" class="logo img-responsive center-block" alt="" style="">
			</a>
		</div>

		<div class="col-lg-5 col-md-6 hidden-sm hidden-xs">
		 <a href="sobreNosotros.php"><h5>SOBRE PROTECH DRY</h5></a>
			<a href="todosLosProductosHombres.php"><h5>HOMBRES</h5></a>
			<a href="todosLosProductosMujeres.php"><h5>MUJERES</h5></a>
		</div>

		<div class="hidden-lg hidden-md col-sm-8 hidden-xs">
		 <a href="sobreNosotros.php"><h5>SOBRE PROTECH DRY</h5></a>
			<a href="todosLosProductosHombres.php"><h5>HOMBRES</h4></a>
			<a href="todosLosProductosMujeres.php"><h5>MUJERES</h5></a>
		</div>

	

		<div class="col-lg-4 col-md-2 col-sm-2 col-xs-6" style="height:50px;padding:0;">
		    <ul class="right-icons-list" style="list-style:none">
		        <li style="float:left" class="different"><div class="element-menu-carrito" id="mostrar-total-menu" style="float:left;">
						<p id="menu-total"><?php $usuario->mostrarSubtotal();?>$</p>

					</div><!-- mostrar-total-menu -->

					<div id="btn-carrito" class="element-menu-carrito" style="cursor:pointer;">
						 
						<div   class="icon-shopping-cart"><span id="cantidad"> <strong id="cantidad-strong"><?php $usuario->mostrarCantidad();?></strong></span> </div>
					</div>
				</li>
		        <li style="float:left"><a href="https://www.facebook.com/ProtechDryArgentina/" target="_blank"><img src="img/icons/header-icons-14.png" class="red-soci-icon-menu" alt=""></a></li>
		        <li style="float:left;"><a href="https://www.instagram.com/protechdryargentina/" target="_blank"><img src="img/icons/header-icons-15.png" class="red-soci-icon-menu" alt=""></a></li>
		        <li style="float:left;margin-left:18px"><img src="img/icons/contacto-directo-icon.png" style="width:33px !important;vertical-align: baseline;"></li>
		        <li style="float:left;margin-top:1px;margin-left:6px;" >
		            <p style="margin:0px;">Consultas directas</p>
		        <p style="color: #a02a4e;margin-bottom: 0px;">
			           011 15 5473 2203 
			    
			    </p>       
			    </li>
		        
		    </ul>
			<div class="icon-cont" style="">
				
			</div>
			<div class="icon-cont">
				
			</div>
			<div class="icon-cont">
				
			</div>
	
			
			<div class="icon-cont">
			    <ul style="list-style:none;padding-left:13px;">
			        <li style="display:inline-block">
			            
			        </li>
			        <li style="display:inline-block">
			            
			        </li>
			    </ul>
			</div>
			

		</div>

		


	</div>
</div>
</div>
<div class="row menu" id="primer-row-xs" style="padding: 2% 1% 1%;z-index: 10000;">
	<div class="container">
		<div class="col-lg-3 col-md-3 col-sm-2 col-xs-6">
			<a href="index.php">
				<img src="elementos_separados/logo.png" class="logo img-responsive center-block" alt="" style="">
			</a>
		</div>

		<div class="col-lg-5 col-md-6 hidden-sm hidden-xs">
		 <a href="sobreNosotros.php"><h5>SOBRE PROTECH DRY</h5></a>
			<a href="todosLosProductosHombres.php"><h5>HOMBRES</h5></a>
			<a href="todosLosProductosMujeres.php"><h5>MUJERES</h5></a>
		</div>

		<div class="hidden-lg hidden-md col-sm-8 hidden-xs">
		 <a href="sobreNosotros.php"><h5>SOBRE PROTECH DRY</h5></a>
			<a href="todosLosProductosHombres.php"><h5>HOMBRES</h4></a>
			<a href="todosLosProductosMujeres.php"><h5>MUJERES</h5></a>
		</div>

	

		<div class="col-lg-4 col-md-2 col-sm-2 col-xs-6" style="height:50px;padding:0;">
		    <ul class="right-icons-list" style="list-style:none">
		        <li style="float:left" class="different"><div class="element-menu-carrito" id="mostrar-total-menu" style="float:left;">
						<p id="menu-total"><?php $usuario->mostrarSubtotal();?>$</p>

					</div><!-- mostrar-total-menu -->

					<div id="btn-carrito-cel" class="element-menu-carrito" style="cursor:pointer;">
						 
						<div   class="icon-shopping-cart"><span id="cantidad"> <strong id="cantidad-strong"><?php $usuario->mostrarCantidad();?></strong></span> </div>
					</div>
				</li>
		        <li style="float:left"><a href="https://www.facebook.com/ProtechDryArgentina/" target="_blank"><img src="img/icons/header-icons-14.png" class="red-soci-icon-menu" alt=""></a></li>
		        <li style="float:left;"><a href="https://www.instagram.com/protechdryargentina/" target="_blank"><img src="img/icons/header-icons-15.png" class="red-soci-icon-menu" alt=""></a></li>
		        <li style="float:left;margin-left:18px"><img src="img/icons/contacto-directo-icon.png" style="width:33px !important;vertical-align: baseline;"></li>
		        <li style="float:left;margin-top:1px;margin-left:6px;" >
		            <p style="margin:0px;">Consultas directas</p>
		        <p style="color: #a02a4e;margin-bottom: 0px;">
			           011 15 5473 2203 
			    
			    </p>       
			    </li>
		        
		    </ul>
			<div class="icon-cont" style="">
				
			</div>
			<div class="icon-cont">
				
			</div>
			<div class="icon-cont">
				
			</div>
	
			
			<div class="icon-cont">
			    <ul style="list-style:none;padding-left:13px;">
			        <li style="display:inline-block">
			            
			        </li>
			        <li style="display:inline-block">
			            
			        </li>
			    </ul>
			</div>
			

		</div>

		


	</div>
</div>
</div>

<!-- CARRITO DE COMPRAS !! -->
 <!-- CARRITO DE COMPRAS !! -->
<div id="carrito" class="animated slideInDown carrito-ver-mas" style="    margin-top: 0%">

	<i id="carrito-close" class="material-icons"  onClick="cerrarVentanaCarrito();">close</i>
	<ul id="carrito-lista">
		<?php 

		$bd=new BaseDatos();
		$usuario->mostrarCarrito();

		?>
	</ul>
</div>
	<div class="gradient-border"></div>


