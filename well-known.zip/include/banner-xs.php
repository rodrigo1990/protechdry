<!--<div class="row banner-xs-row" style="display:none">
    <div class="col-xs-12 hidden-sm hidden-md hidden-lg" style="padding:0 !important">
        <div class="owl-carousel">
        <div>
	  	<img src="banners/banner-xs-home-1.jpg" class="img-banner"  width="100%" alt="Protech Dry">
		<div class="banner-info-xs" id="banner-xs-1">
		
			<button class="banner-xs-button">COMPRAR</button>
		</div>

	  </div>
	  <div>
	  	<img src="banners/banner-xs-home-2.jpg" class="img-banner"  width="100%" alt="Protech Dry">
	  	<div class="banner-info-xs-2" id='banner-2' style="margin-top: -148%;color:white;">
	  	    
	  	    <img src="img/icons/banner-icon-2.png" style=" margin-left: auto;
    margin-right: auto;
    width: 192px;">
    <div class="container text-center">
        <h2 style="font-weight:bolder;font-style:italic;">ENVÍO GRATUITO CABA Y GRAN BUENOS AIRES</h2>
        <h2 style="font-style:italic">Envíos a todo el país</h2>
        <button  class="banner-xs-button">COMPRAR</button>
	 </div> 
	  </div>
	  </div>
	  
        </div>
    </div>
</div>-->