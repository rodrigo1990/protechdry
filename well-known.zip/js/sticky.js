  $(document).ready(function(){
    $("#primer-row").sticky({topSpacing:0});
    
 
    
    
  });

    